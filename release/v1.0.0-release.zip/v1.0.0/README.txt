SwissAirDry v1.0.0 Release-Paket
====================================

Erstellungsdatum: Fri 09 May 2025 09:09:39 PM UTC
Release-Tag: ins
Commit-Hash: f307b0c

Inhalt:
- Installationsskripte für Linux/Mac und Windows
- Quickstart-Skripte für einfachen Start
- Wartungs- und Update-Tools
- Release-Dokumentation
- Changelog mit Versionshistorie

Installationsanleitung:
1. Für Linux/Mac: 
   chmod +x install.sh
   ./install.sh

2. Für Windows:
   install.bat

Oder direkt starten mit:
- Linux/Mac: ./swissairdry-quickstart.sh
- Windows: swissairdry-quickstart.bat

Dieses Release fügt das Domain-Management-System mit
Cloudflare API-Integration hinzu. Siehe RELEASE_NOTES.md
für weitere Details.
