"""
SwissAirDry Main Package

Dieses Paket enthält die verschiedenen Komponenten des SwissAirDry-Systems.
"""

__version__ = "1.0.0"
__author__ = "Swiss Air Dry Team"
__email__ = "info@swissairdry.com"
__copyright__ = "Copyright 2023-2025 Swiss Air Dry Team"