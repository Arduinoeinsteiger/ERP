"""
SwissAirDry API-Tests

Dieses Paket enthält Testfälle für die SwissAirDry API.
"""