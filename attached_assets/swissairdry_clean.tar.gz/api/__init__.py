"""
SwissAirDry API Package

Dieses Paket enthält die API-Komponenten des SwissAirDry-Systems.
"""